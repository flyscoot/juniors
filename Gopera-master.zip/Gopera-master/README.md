# Gopera
How To RUN?

#via ANDROID - Termux
1. pkg install git
2. pkg install python
3. pip3 install akad
4. pip3 install rsa
5. pip3 install requests
6. pip3 install googletrans
7. pip3 install bs4
8. pip3 install requests 
9. pip3 install rsa
10. pip3 install thrift
11. pip3 install bs4
12. pip3 install pytz
13. pip3 install humanfriendly
14. pip3 install gtts
15. pip3 install googletrans
16. pip3 install wikipedia
17. pip3 install youtube_dl
18. pip3 install ffmpy
19. termux-setup-storage
20. apt update
21. apt upgrade

-->> View more tutorial at https://www.jurustupai.com/2019/09/cara-membuat-selfbot-di-line.html

#via VPS
1. sudo apt-get install git
2. git clone https://github.com/goodop/Gopera
3. sudo apt-get python3-pip
4. sude pip3 install rsa
5. sudo pip3 install requests
6. sudo pip3 install googletrans
7. sudo pip3 install bs4
8. sudo pip3 install requests 9 .sudo pip3 install rsa
9. sudo pip3 install thrift
10. sudo pip3 install bs4
11. sudo pip3 install pytz
12. sudo pip3 install humanfriendly
13. sudo pip3 install gtts
14. sudo pip3 install googletrans
15. sudo pip3 install wikipedia
16. sudo pip3 install youtube_dl
17. sudo pip3 install ffmpy
18. cd Gopera
19. python3 sb.py

#This script not made by me, I just edited to make it so easy to use.

#for more please visit https://github.com/arifistifik/dpk
